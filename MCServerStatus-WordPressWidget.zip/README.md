> This a fork from [MCNewsTools/MCServerStatus-WordPressWidget](https://github.com/MCNewsTools/MCServerStatus-WordPressWidget). I will optimize its functions to make it more convenient to fetch the server status for **Minecraft Java Edition**.

# Server Status For Minecraft PC (MCServerStatus)
Server Status For Minecraft PC is a WordPress Widget, show Minecraft Java editions server data.

[Download this plugin](https://wordpress.org/plugins/server-status-for-minecraft-pc-pe)

You can display / hide these information:

 * Server name (MOTD)
 * Status (online/offline)
 * IP address / hostname
 * Port
 * Server platform
 * Server software
 * Game version
 * Website
 * DynMap
 * Player count (current / maximum)
 * Player list
 * Player skin avatar

and more features are planned.

Other functions:

 * Display web site link
 * DynMap
 * Set player avatar size
 * Auto update status

