<?php

namespace GoneTone\xPaw;

class MinecraftPingException extends \Exception
{
	// Exception thrown by MinecraftPing class
}
